﻿using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
namespace MetinwebFinal
{
	class Program
	{
		static void Main(string[] args)
		{
			List<List<string>> list = new List<List<string>>();
			//List<string> satir = new List<string>();
            List<int> kullanici = new List<int>();
			FileStream fs = new FileStream(@"restoran-oneri.txt", FileMode.Open, FileAccess.Read);
			StreamReader sr = new StreamReader(fs);
	        string val = sr.ReadLine();
            val = sr.ReadLine();
            while (val != null)
            {

                string[] m = val.Split(',');
                List<string> satir = new List<string>();
                foreach (var item in m)
                {
                   
                    satir.Add(item);
                   

                }
                list.Add(satir);
                val = sr.ReadLine();

            }
            
            Kullanici k = new Kullanici();
            kullanici = k.Kullaniciyorum();
            CosBenzerliği c = new CosBenzerliği();
            bool oldumu= c.CosHesapla(list, kullanici);
            while(oldumu==false)
            {
                kullanici = k.Kullaniciyorum();
                oldumu= c.CosHesapla(list, kullanici);
            }

           
             
           









        }
	}
}
