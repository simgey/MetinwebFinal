﻿using System;
using System.Collections.Generic;
using System.Linq;
namespace MetinwebFinal
{
    public class CosBenzerliği
    {
        public bool CosHesapla(List<List<string>> liste,List<int> kullanici)
        {
           
            List<string> restno = new List<string>();
            List<double> s = new List<double>();
            int i;
            foreach(var item in liste)
            {
                double sonuc=0;
                double pay = 0;
                double payda1 = 0;
                double payda2 = 0;
                for (i = 1;i< 8;i++)
                {
                    if(item[i] !="?")
                    {
                        pay += (Convert.ToInt32(item[i]) * kullanici[i]);
                        payda1 += Math.Pow(Convert.ToInt32(item[i]), 2);
                        payda2 += Math.Pow(kullanici[i], 2);
                    }

                  
                }
                payda1 = Math.Sqrt(payda1);
                payda2 = Math.Sqrt(payda2);
                sonuc = pay / (payda1 * payda2);
               
                restno.Add(item[0]);
                s.Add(sonuc);
               
                
                
                
                
            }
            double max = s.Max();
            if(max<0.5)
            {
                Console.WriteLine("Tercihlerinize uygun restoran pek yok gibi...Yine de listelemek ister misiniz?");
                Console.WriteLine("Listelemek için 1,tekrardan değer girmek için herhangi bir rakamı tuşlayınız(1 hariç)");
                int cevap = Console.Read();
                if(cevap==1)
                {
                    List<double> farkli = new List<double>();
                    List<double> listelenecek = new List<double>();
                    farkli = s.Distinct().ToList();
                    farkli.Sort();
                    farkli.Reverse();
                    int sayac = 0;
                    while (sayac < kullanici[0])
                    {
                        listelenecek.Add(farkli[sayac]);
                        sayac++;
                    }
                    foreach (var item in listelenecek)
                    {
                        for (i = 0; i < s.Count; i++)
                        {
                            if (s[i] == item)
                            {
                                Console.WriteLine("Restoran no-->" + restno[i] + " ve " + "Cos benzerlik degeri-->" + s[i]);
                            }
                        }
                    }
                }
                else
                {
                    return false;
                }
            }
            else
            {
                List<double> farkli = new List<double>();
                List<double> listelenecek = new List<double>();
                farkli = s.Distinct().ToList();
                farkli.Sort();
                farkli.Reverse();
                int sayac = 0;
                while (sayac < kullanici[0])
                {
                    listelenecek.Add(farkli[sayac]);
                    sayac++;
                }
                foreach (var item in listelenecek)
                {
                    for (i = 0; i < s.Count; i++)
                    {
                        if (s[i] == item)
                        {
                            Console.WriteLine("Restoran no-->" + restno[i] + " ve " + "Cos benzerlik degeri-->" + s[i]);
                        }
                    }
                }
               
            }

            return true;


        }
    }
}
