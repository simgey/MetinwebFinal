﻿using System;
using System.Collections.Generic;
namespace MetinwebFinal
{
    class Kullanici
    {
        public List<int> Kullaniciyorum()
        {
            List<int> kullaniciyorum = new List<int>();
            
            Console.WriteLine("Öncelikle kac adet restoran listememizi istersiniz (min:1 - max:15)");
            int sayi = Convert.ToInt32(Console.ReadLine());
            kullaniciyorum.Add(sayi);
            Console.WriteLine("Hoşgeldiniz :)");
            Console.WriteLine("Aradıgınız restoran a en yakın  ozelliklerdeki mekani bulabilmek icin asagida belirtilen kistaslara 1-10 arasi deger veriniz :)");
            Console.WriteLine("Ortam Sıklıgı:");
            int cevap = Convert.ToInt32(Console.ReadLine());
            kullaniciyorum.Add(cevap);
            Console.WriteLine("Ortam Temizligi:");
            int cevap2 = Convert.ToInt32(Console.ReadLine());
            kullaniciyorum.Add(cevap2);
            Console.WriteLine("Yemek Kalitesi:");
            int cevap3 = Convert.ToInt32(Console.ReadLine());
            kullaniciyorum.Add(cevap3);
            Console.WriteLine("Hizmet Kalitesi:");
            int cevap4 = Convert.ToInt32(Console.ReadLine());
            kullaniciyorum.Add(cevap4);
            Console.WriteLine("Fiyat Uygunlugu:");
            int cevap5 = Convert.ToInt32(Console.ReadLine());
            kullaniciyorum.Add(cevap5);
            Console.WriteLine("Ulasim Kolayligi:");
            int cevap6 = Convert.ToInt32(Console.ReadLine());
            kullaniciyorum.Add(cevap6);
            Console.WriteLine("Araba Park Olanagi:");
            int cevap7 = Convert.ToInt32(Console.ReadLine());
            kullaniciyorum.Add(cevap7);
          
            return kullaniciyorum;

        }
    }
}
